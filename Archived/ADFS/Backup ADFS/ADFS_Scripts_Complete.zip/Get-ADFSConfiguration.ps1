#Requires -RunAsAdministrator
#Requires -Modules ADFS

<#
.SYNOPSIS
    Hämtar komplett ADFS-konfiguration inkl. claims, certifikat, förlitandeparter osv.
.DESCRIPTION
    Skriptet exporterar all ADFS-konfiguration till JSON-fil för analys och dokumentation.
.PARAMETER OutputPath
    Sökväg där konfigurationen sparas (default: C:\ADFS_Config)
.EXAMPLE
    .\Get-ADFSConfiguration.ps1 -OutputPath "C:\ADFS_Config"
#>

param(
    [string]$OutputPath = "C:\ADFS_Config",
    [switch]$OpenReport
)

# Funktion för att logga
function Write-Log {
    param($Message, [ValidateSet("Info", "Success", "Warning", "Error")]$Level = "Info")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = @{Info = "White"; Success = "Green"; Warning = "Yellow"; Error = "Red"}
    Write-Host "[$timestamp] $Message" -ForegroundColor $color[$Level]
}

# Skapa output-mapp
if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
    Write-Log "Skapade mapp: $OutputPath" "Success"
}

$config = @{}

try {
    Write-Log "Hämtar ADFS-tjänstinformation..." "Info"

    # ===== ADFS SERVICE CONFIGURATION =====
    $config.ServiceInfo = @{
        ServiceName = (Get-ADFSProperties).DisplayName
        ServiceRole = (Get-ADFSProperties).Role
        FullyQualifiedDomainName = (Get-ADFSProperties).HostName
        Status = (Get-ADFSServiceStatus).ServiceState
        Version = (Get-ADFSProperties).ProductVersion
        Timestamp = Get-Date -Format "o"
    }

    # ===== CERTIFIKAT =====
    Write-Log "Hämtar certifikat..." "Info"
    $config.Certificates = @{
        ServiceCommunicationCertificate = @(
            Get-ADFSCertificate | Where-Object { $_.CertificateType -eq "Service-Communication" } | ForEach-Object {
                @{
                    Thumbprint = $_.Thumbprint
                    SubjectName = $_.Certificate.Subject
                    IssuerName = $_.Certificate.Issuer
                    ValidFrom = $_.Certificate.NotBefore
                    ValidTo = $_.Certificate.NotAfter
                    DaysToExpiry = ($_.Certificate.NotAfter - (Get-Date)).Days
                    CertificateHash = $_.Thumbprint
                }
            }
        )
        TokenSigningCertificate = @(
            Get-ADFSCertificate | Where-Object { $_.CertificateType -eq "Token-Signing" } | ForEach-Object {
                @{
                    Thumbprint = $_.Thumbprint
                    SubjectName = $_.Certificate.Subject
                    IssuerName = $_.Certificate.Issuer
                    ValidFrom = $_.Certificate.NotBefore
                    ValidTo = $_.Certificate.NotAfter
                    DaysToExpiry = ($_.Certificate.NotAfter - (Get-Date)).Days
                    IsPrimary = $_.IsPrimary
                }
            }
        )
    }

    # ===== FÖRLITANDEPARTER (RELYING PARTIES) =====
    Write-Log "Hämtar förlitandeparter..." "Info"
    $relyingParties = Get-ADFSRelyingPartyTrust
    $config.RelyingParties = @()

    foreach ($rp in $relyingParties) {
        $rpConfig = @{
            Identifier = $rp.Identifier
            Name = $rp.Name
            Enabled = $rp.Enabled
            AccessControlPolicyName = $rp.AccessControlPolicyName
            ClaimsProviderName = $rp.ClaimsProviderName
            ProtocolProfile = $rp.ProtocolProfile
            RequestSigningCertificateRevocationCheck = $rp.RequestSigningCertificateRevocationCheck
            SigningCertificateRevocationCheck = $rp.SigningCertificateRevocationCheck
            SignedSamlRequestsRequired = $rp.SignedSamlRequestsRequired
            SamlResponseSignature = $rp.SamlResponseSignature
            WsFedEndpoint = $rp.WSFedEndpoint
            MetadataUrl = $rp.MetadataUrl
            MonitoringEnabled = $rp.MonitoringEnabled
            Notes = $rp.Notes
            IssuanceAuthorizationRules = $rp.IssuanceAuthorizationRules
            IssuanceTransformRules = $rp.IssuanceTransformRules

            # Signeringscertifikat
            SigningCertificates = @($rp.SigningCertificate | ForEach-Object {
                @{
                    Thumbprint = $_
                    Certificate = (Get-ChildItem Cert:\LocalMachine\My\$_).Subject
                }
            })

            # WS-Fed och SAML endpoints
            WsFedEndpoints = @(
                $rp.WSFedEndpoint | ForEach-Object { @{ Endpoint = $_ } }
            )

            SamlEndpoints = @(
                $rp.SamlEndpoints | ForEach-Object {
                    @{
                        Binding = $_.Binding
                        Location = $_.Location
                        Index = $_.Index
                        IsDefault = $_.IsDefault
                    }
                }
            )
        }

        $config.RelyingParties += $rpConfig
    }

    # ===== CLAIMS PROVIDER TRUSTS =====
    Write-Log "Hämtar claims provider-förtroenden..." "Info"
    $claimsProviders = Get-ADFSClaimsProviderTrust
    $config.ClaimsProviders = @()

    foreach ($cp in $claimsProviders) {
        $cpConfig = @{
            Identifier = $cp.Identifier
            Name = $cp.Name
            Enabled = $cp.Enabled
            ProtocolSupportEnumeration = $cp.ProtocolSupportEnumeration
            MonitoringEnabled = $cp.MonitoringEnabled
            Notes = $cp.Notes
            IssuanceAuthorizationRules = $cp.IssuanceAuthorizationRules
            IssuanceTransformRules = $cp.IssuanceTransformRules
            AcceptanceTransformRules = $cp.AcceptanceTransformRules

            # Endpoints
            Endpoints = @()
        }

        if ($cp.Endpoints) {
            $cpConfig.Endpoints = @(
                $cp.Endpoints | ForEach-Object {
                    @{
                        Protocol = $_.Protocol
                        Binding = $_.Binding
                        Location = $_.Location
                    }
                }
            )
        }

        $config.ClaimsProviders += $cpConfig
    }

    # ===== CLAIMS RULES =====
    Write-Log "Hämtar claims-regler..." "Info"
    $config.ClaimsRules = @{
        RelyingPartyClaimsRules = @()
        ClaimsProviderClaimsRules = @()
    }

    # Förlitandeparters claims-regler
    foreach ($rp in $relyingParties) {
        $config.ClaimsRules.RelyingPartyClaimsRules += @{
            RelyingPartyName = $rp.Name
            IssuanceAuthorizationRules = $rp.IssuanceAuthorizationRules
            IssuanceTransformRules = $rp.IssuanceTransformRules
            DelegationAuthorizationRules = $rp.DelegationAuthorizationRules
        }
    }

    # Claims provider-regler
    foreach ($cp in $claimsProviders) {
        $config.ClaimsRules.ClaimsProviderClaimsRules += @{
            ClaimsProviderName = $cp.Name
            IssuanceAuthorizationRules = $cp.IssuanceAuthorizationRules
            IssuanceTransformRules = $cp.IssuanceTransformRules
            AcceptanceTransformRules = $cp.AcceptanceTransformRules
        }
    }

    # ===== ATTRIBUTE STORES =====
    Write-Log "Hämtar attributlager..." "Info"
    $config.AttributeStores = @(
        Get-ADFSAttributeStore | ForEach-Object {
            @{
                Name = $_.Name
                Type = $_.Type
                Configuration = $_.Configuration
            }
        }
    )

    # ===== SCOPE DESCRIPTIONS =====
    Write-Log "Hämtar scope-beskrivningar..." "Info"
    $config.ScopeDescriptions = @(
        Get-ADFSScopeDescription | ForEach-Object {
            @{
                Name = $_.Name
                Description = $_.Description
                Identifier = $_.Identifier
            }
        }
    )

    # ===== GLOBALA POLICY-INSTÄLLNINGAR =====
    Write-Log "Hämtar globala inställningar..." "Info"
    $adfsProperties = Get-ADFSProperties
    $config.GlobalSettings = @{
        DisplayName = $adfsProperties.DisplayName
        OrganizationName = $adfsProperties.OrganizationName
        OrganizationalUnitName = $adfsProperties.OrganizationalUnitName
        WebApplicationProxyConfiguration = $adfsProperties.WebApplicationProxyConfiguration
        ExtendedProperties = $adfsProperties.ExtendedProperties
        AutoCertificateRollover = $adfsProperties.AutoCertificateRollover
        CertificateCriticalThresholdDays = $adfsProperties.CertificateCriticalThresholdDays
        CertificatePromotionThresholdDays = $adfsProperties.CertificatePromotionThresholdDays
        CertificateRolloverInterval = $adfsProperties.CertificateRolloverInterval
        CertificateSharingContainer = $adfsProperties.CertificateSharingContainer
        CertificateThresholdDays = $adfsProperties.CertificateThresholdDays
        HostName = $adfsProperties.HostName
        HttpPort = $adfsProperties.HttpPort
        HttpsPort = $adfsProperties.HttpsPort
        IntranetUseMultiLanguage = $adfsProperties.IntranetUseMultiLanguage
        Proxies = $adfsProperties.Proxies
    }

    # ===== AUTHENTICATION POLICIES =====
    Write-Log "Hämtar autentiseringsprinciper..." "Info"
    try {
        $config.AuthenticationPolicies = @(
            Get-AdfsAuthenticationPolicy | ForEach-Object {
                @{
                    Name = $_.Name
                    UserAuthenticationPolicy = $_.UserAuthenticationPolicy
                    ExtranetAuthenticationPolicy = $_.ExtranetAuthenticationPolicy
                    DeviceAuthenticationEnabled = $_.DeviceAuthenticationEnabled
                }
            }
        )
    } catch {
        Write-Log "Kunde inte hämta autentiseringsprinciper (kan kräva senare ADFS-version)" "Warning"
    }

    # ===== ADMIN ACCOUNTS =====
    Write-Log "Hämtar ADFS-administratörer..." "Info"
    try {
        $config.AdminAccounts = @(
            Get-ADFSAdministrationRole | ForEach-Object {
                @{
                    Identifier = $_.Identifier
                    Role = $_.Role
                }
            }
        )
    } catch {
        Write-Log "Kunde inte hämta administratörsroller" "Warning"
    }

    # ===== ENDPOINT KONFIGURATION =====
    Write-Log "Hämtar endpoints..." "Info"
    $config.Endpoints = @(
        Get-ADFSEndpoint | ForEach-Object {
            @{
                FullUrl = $_.FullUrl
                Protocol = $_.Protocol
                AddressPath = $_.AddressPath
                Enabled = $_.Enabled
            }
        }
    )

    # ===== EXPORT TILL JSON =====
    Write-Log "Exporterar konfiguration till JSON..." "Info"
    $jsonPath = Join-Path $OutputPath "ADFS_Config_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $config | ConvertTo-Json -Depth 10 | Out-File -FilePath $jsonPath -Encoding UTF8
    Write-Log "Sparad JSON: $jsonPath" "Success"

    # ===== EXPORT TILL HTML-RAPPORT =====
    Write-Log "Skapar HTML-rapport..." "Info"
    $htmlPath = Join-Path $OutputPath "ADFS_Config_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"

    $htmlContent = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ADFS-konfigurationsrapport</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { color: #0078d4; border-bottom: 2px solid #0078d4; padding-bottom: 10px; }
        h2 { color: #106ebe; margin-top: 30px; }
        table { border-collapse: collapse; width: 100%; margin: 15px 0; background-color: white; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #0078d4; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .info-box { background-color: #e3f2fd; border-left: 4px solid #0078d4; padding: 15px; margin: 10px 0; }
        .warning { color: #d32f2f; font-weight: bold; }
        .success { color: #388e3c; font-weight: bold; }
        pre { background-color: #f5f5f5; padding: 10px; overflow-x: auto; border-radius: 4px; }
        .expiry-critical { background-color: #ffebee; }
        .expiry-warning { background-color: #fff3e0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>ADFS-konfigurationsrapport</h1>
        <div class="info-box">
            <p><strong>Genererad:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
        </div>
"@

    # Service Info
    $htmlContent += @"
        <h2>1. ADFS-tjänstinformation</h2>
        <table>
            <tr><th>Egenskap</th><th>Värde</th></tr>
            <tr><td>Tjänstnamn</td><td>$($config.ServiceInfo.ServiceName)</td></tr>
            <tr><td>Roll</td><td>$($config.ServiceInfo.ServiceRole)</td></tr>
            <tr><td>Värdnamn</td><td>$($config.ServiceInfo.FullyQualifiedDomainName)</td></tr>
            <tr><td>Status</td><td class="success">$($config.ServiceInfo.Status)</td></tr>
            <tr><td>Version</td><td>$($config.ServiceInfo.Version)</td></tr>
        </table>
"@

    # Certifikat
    $htmlContent += @"
        <h2>2. Certifikat</h2>
        <h3>Token-signeringscertifikat</h3>
        <table>
            <tr><th>Namn</th><th>Thumbprint</th><th>Giltig till</th><th>Dagar kvar</th><th>Status</th></tr>
"@

    foreach ($cert in $config.Certificates.TokenSigningCertificate) {
        $daysLeft = $cert.DaysToExpiry
        $statusClass = if ($daysLeft -lt 30) { "expiry-critical" } elseif ($daysLeft -lt 90) { "expiry-warning" } else { "" }
        $statusText = if ($daysLeft -lt 0) { "<span class='warning'>UTGÅNGET</span>" } else { "$daysLeft dagar" }
        $htmlContent += "<tr class='$statusClass'><td>$($cert.SubjectName)</td><td>$($cert.Thumbprint)</td><td>$($cert.ValidTo)</td><td>$statusText</td><td>$(if($cert.IsPrimary){'Primär'}else{'Backup'})</td></tr>"
    }

    $htmlContent += @"
        </table>

        <h2>3. Förlitandeparter ($(($config.RelyingParties | Measure-Object).Count))</h2>
        <table>
            <tr><th>Namn</th><th>Identifierare</th><th>Aktiverad</th><th>Protocol</th><th>Metadata</th></tr>
"@

    foreach ($rp in $config.RelyingParties) {
        $enabled = if ($rp.Enabled) { "<span class='success'>✓</span>" } else { "<span class='warning'>✗</span>" }
        $htmlContent += "<tr><td>$($rp.Name)</td><td>$($rp.Identifier[0])</td><td>$enabled</td><td>$($rp.ProtocolProfile)</td><td><a href='$($rp.MetadataUrl)' target='_blank'>Metadata</a></td></tr>"
    }

    $htmlContent += @"
        </table>

        <h2>4. Claims Provider-förtroenden ($(($config.ClaimsProviders | Measure-Object).Count))</h2>
        <table>
            <tr><th>Namn</th><th>Identifierare</th><th>Aktiverad</th><th>Protokoll</th></tr>
"@

    foreach ($cp in $config.ClaimsProviders) {
        $enabled = if ($cp.Enabled) { "<span class='success'>✓</span>" } else { "<span class='warning'>✗</span>" }
        $htmlContent += "<tr><td>$($cp.Name)</td><td>$($cp.Identifier)</td><td>$enabled</td><td>$($cp.ProtocolSupportEnumeration -join ', ')</td></tr>"
    }

    $htmlContent += @"
        </table>

        <h2>5. Attributlager ($(($config.AttributeStores | Measure-Object).Count))</h2>
        <table>
            <tr><th>Namn</th><th>Typ</th></tr>
"@

    foreach ($as in $config.AttributeStores) {
        $htmlContent += "<tr><td>$($as.Name)</td><td>$($as.Type)</td></tr>"
    }

    $htmlContent += @"
        </table>

        <h2>6. Globala inställningar</h2>
        <table>
            <tr><th>Inställning</th><th>Värde</th></tr>
            <tr><td>Organisationsnamn</td><td>$($config.GlobalSettings.OrganizationName)</td></tr>
            <tr><td>Auto-certifikatöverrollning</td><td>$($config.GlobalSettings.AutoCertificateRollover)</td></tr>
            <tr><td>Certifikat-övergångsdagar</td><td>$($config.GlobalSettings.CertificateThresholdDays)</td></tr>
            <tr><td>HTTP-port</td><td>$($config.GlobalSettings.HttpPort)</td></tr>
            <tr><td>HTTPS-port</td><td>$($config.GlobalSettings.HttpsPort)</td></tr>
        </table>

        <p style="margin-top: 40px; color: #666; font-size: 12px;">
            <strong>Datafiler:</strong><br>
            JSON-export: <code>ADFS_Config_*.json</code><br>
            Denna rapport genererades automatiskt av Get-ADFSConfiguration.ps1
        </p>
    </div>
</body>
</html>
"@

    $htmlContent | Out-File -FilePath $htmlPath -Encoding UTF8
    Write-Log "Sparad HTML-rapport: $htmlPath" "Success"

    # Öppna rapport om önskat
    if ($OpenReport) {
        Invoke-Item $htmlPath
    }

    Write-Log "✓ ADFS-konfigurationen exporterad framgångsrikt!" "Success"
    Write-Log "Filerna sparades i: $OutputPath" "Info"

} catch {
    Write-Log "Fel vid hämtning av konfiguration: $_" "Error"
    exit 1
}
