# ADFS Konfigurationsexport Scripts

Omfattande PowerShell-scripts för att exportera och analysera Active Directory Federation Services (ADFS) konfiguration.

## 📋 Innehål

- **Get-ADFSConfiguration.ps1** - Huvudscript för att hämta all ADFS-konfiguration
- **Get-ADFSConfigAnalysis.ps1** - Analysscript för att kontrollera hälsa och säkerhet
- **README_ADFS_Scripts.md** - Denna dokumentation

## 🚀 Snabbstart

### Kravkrav
- Windows Server med ADFS installerad
- PowerShell 5.0 eller senare
- Administratörsrättigheter
- ADFS PowerShell-modul

### Grundläggande användning

```powershell
# Exportera all konfiguration
.\Get-ADFSConfiguration.ps1 -OutputPath "C:\ADFS_Config"

# Exportera och öppna HTML-rapport
.\Get-ADFSConfiguration.ps1 -OutputPath "C:\ADFS_Config" -OpenReport

# Analysera hälsa
.\Get-ADFSConfigAnalysis.ps1 -OutputPath "C:\ADFS_Config"
```

## 📊 Output-filer

### Get-ADFSConfiguration.ps1 producerar:

1. **ADFS_Config_*.json** - Komplett konfiguration i JSON-format
   - Perfekt för version control och dokumentation
   - Lätt att jämföra mellan två tillfällen

2. **ADFS_Config_*.html** - Visuell rapport
   - Läsbar i webbläsare
   - Visar certifikatstatus, förlitandeparter, claims providers
   - Certifikatförfall markerade i farger (röd = kritisk, orange = varning)

### Get-ADFSConfigAnalysis.ps1 producerar:

1. **ADFS_Analysis_*.json** - Detaljerade analysresultat
2. **ADFS_Issues_*.csv** - Problem exporterade för behandling

## 📝 Hämtad information

### Tjänstinformation
- Servicenamn och roll
- Värdnamn och status
- ADFS-version
- HTTP/HTTPS-portar

### Certifikat
- **Token-signeringscertifikat** - För att signera säkerhetstokens
  - Giltighet och utgångsdatum
  - Antal dagar kvar
  - Primär/backup-status
  
- **Service Communication** - För ADFS-tjänstens egen kommunikation
  - Utfärdare och giltighetsperiod

### Förlitandeparter (Relying Parties)
- Namn och identifierare
- Aktiveringstatus
- WS-Fed och SAML endpoints
- Metadata-URL
- Signeringscertifikat
- Issuance-regler (authorization + transform)
- Monitoringstatus

### Claims Providers
- Namn och identifierare
- Aktiveringstatus
- Protokollstöd (SAML, WS-Fed)
- Endpoints-konfiguration
- Issuance och acceptance-regler

### Claims Rules
- Issuance Authorization Rules - Vem får token?
- Issuance Transform Rules - Vilka claims ska ingå?
- Acceptance Transform Rules - Hur bearbetar vi inkommande claims?

### Attributlager (Attribute Stores)
- Active Directory
- LDAP
- SQL Server
- Anpassade attributlager

### Globala inställningar
- Organisationsnamn
- Auto-certifikatöverrollning
- Certifikat-övergångstider
- WAP-konfiguration
- Port-inställningar

### Endpoints
- WS-Federation endpoints
- SAML 2.0 endpoints
- OAuth 2.0 endpoints
- Aktiveringstatus

## 🔍 Analysresultat

Analysisscriptet kontrollerar följande:

### 🚨 Kritiska problem
- Utgångna certifikat
- ADFS-tjänsten körs inte
- DKM-status problem
- Saknade attributlager

### ⚠️ Varningar
- Certifikat utgår inom 90 dagar
- Inaktiverade förlitandeparter
- Inaktiverade claims providers
- Saknade signeringscertifikat

### 💡 Rekommendationer
- Aktivera monitorering på förlitandeparter
- Aktivera auto-certifikatöverrollning
- Konfigurera signeringscertifikat för RP

## 📊 Hälsoscore

Scriptet beräknar ett hälsoscore från 0-100:
- **80-100**: God hälsa ✓
- **60-80**: Varningsfasen ⚠️
- **0-60**: Kritisk åtgärd behövs 🚨

## 💾 Version Control

Föreslagna steg för att versionshantera ADFS-konfiguration:

```bash
# Initialisera git-repo
cd C:\ADFS_Config
git init

# Lägg till konfigurationsfiler
git add ADFS_Config_*.json

# Commit med datum
git commit -m "ADFS config snapshot $(Get-Date -Format 'yyyy-MM-dd')"

# Push till remote repo
git push origin main
```

## 🔐 Säkerhet

⚠️ **Viktigt**: JSON-filer kan innehålla känslig information:
- Certifikat-thumbprints
- Endpoint-URL:er
- Reglenkonfiguration

**Rekommendationer:**
- Lagra filer säkert
- Begränsa åtkomst till IT-personal
- Använd .gitignore för sensitive data
- Överväg kryptering för känsliga backuper

```gitignore
# .gitignore
*.json
ADFS_*.csv
ADFS_Issues_*
```

## 🛠️ Avancerad användning

### Jämför två konfigurationer

```powershell
# Exportera två tillfällen
$old = Get-Content "C:\ADFS_Config\ADFS_Config_20250101.json" | ConvertFrom-Json
$new = Get-Content "C:\ADFS_Config\ADFS_Config_20250201.json" | ConvertFrom-Json

# Jämför förlitandeparter
Compare-Object @($old.RelyingParties.Name) @($new.RelyingParties.Name) | 
    Format-Table -AutoSize
```

### Exportera endast kritisk data

```powershell
# Skapa egen funktion för selektiv export
function Export-ADFSCriticalConfig {
    param([string]$Path)
    
    $config = @{
        Certificates = Get-ADFSCertificate | Select-Object CertificateType, Thumbprint, @{N='ExpiresIn';E={($_.Certificate.NotAfter - (Get-Date)).Days}}
        RelyingParties = Get-ADFSRelyingPartyTrust | Select-Object Name, Enabled, MonitoringEnabled
        ClaimsProviders = Get-ADFSClaimsProviderTrust | Select-Object Name, Enabled
    }
    
    $config | ConvertTo-Json | Out-File -Path $Path -Encoding UTF8
}

Export-ADFSCriticalConfig -Path "C:\ADFS_Config\CRITICAL_CONFIG.json"
```

### Automatiserad övervakning

```powershell
# Schemalägg daglig export och analys
$action = New-ScheduledTaskAction -Execute "PowerShell.exe" `
    -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\ADFS_Config\Get-ADFSConfiguration.ps1"

$trigger = New-ScheduledTaskTrigger -Daily -At 02:00AM

Register-ScheduledTask -Action $action -Trigger $trigger `
    -TaskName "ADFS-Config-Export" -Description "Daglig ADFS-konfigurationsexport"
```

## 🐛 Felsökning

### "Kunde inte hämta autentiseringsprinciper"
- Detta kräver ADFS 2016 eller senare
- Funktionen är optional och ignoreras om den inte är tillgänglig

### "Tjänsten är inte tillgänglig"
- Se till att ADFS-tjänsten körs: `Get-ADFSServiceStatus`
- Kontrollera nätverksanslutning till ADFS-servern

### "Åtkomst nekad"
- Scripten kräver administratörsrättigheter
- Kör PowerShell ISE som administratör

## 📞 Support

För ytterligare hjälp:
1. Kontrollera ADFS-dokumentation: https://docs.microsoft.com/en-us/windows-server/identity/active-directory-federation-services
2. Granska Event Viewer → Windows Logs → System och Application
3. Aktivera ADFS-diagnostikloggning: `Get-ADFSDiagnosticsSettings`

## 📄 Licens

Dessa scripts tillhandahålls i befintligt skick för administratörsändamål.

---

**Senast uppdaterad**: 2025-01-XX
**Version**: 1.0
**Kompatibilitet**: Windows Server 2012 R2 och senare, ADFS 2.0 och senare
