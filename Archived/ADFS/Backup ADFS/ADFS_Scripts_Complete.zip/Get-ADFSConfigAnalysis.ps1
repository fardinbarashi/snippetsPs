#Requires -RunAsAdministrator
#Requires -Modules ADFS

<#
.SYNOPSIS
    Analyserar ADFS-konfiguration och rapporterar på säkerhet och hälsa.
.DESCRIPTION
    Utför säker- och hälsokontroller på ADFS-miljön.
#>

param(
    [string]$OutputPath = "C:\ADFS_Config"
)

function Write-Log {
    param($Message, [ValidateSet("Info", "Success", "Warning", "Error")]$Level = "Info")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = @{Info = "White"; Success = "Green"; Warning = "Yellow"; Error = "Red"}
    Write-Host "[$timestamp] $Message" -ForegroundColor $color[$Level]
}

$analysis = @{
    Issues = @()
    Warnings = @()
    Recommendations = @()
    HealthScore = 100
}

try {
    Write-Log "Påbörjar ADFS-hälsokontroll..." "Info"

    # ===== CERTIFIKAT-ANALYS =====
    Write-Log "Analyserar certifikat..." "Info"
    $certs = Get-ADFSCertificate

    foreach ($cert in $certs) {
        $daysToExpiry = ($cert.Certificate.NotAfter - (Get-Date)).Days

        if ($daysToExpiry -lt 0) {
            $analysis.Issues += "🚨 KRITISK: Certifikat $($cert.Certificate.Subject) har utgått!"
            $analysis.HealthScore -= 25
        } elseif ($daysToExpiry -lt 30) {
            $analysis.Issues += "⚠️  AKUT: Certifikat $($cert.Certificate.Subject) utgår om $daysToExpiry dagar!"
            $analysis.HealthScore -= 15
        } elseif ($daysToExpiry -lt 90) {
            $analysis.Warnings += "Certifikat $($cert.Certificate.Subject) utgår om $daysToExpiry dagar"
            $analysis.HealthScore -= 5
        }
    }

    # ===== TJÄNSTSTATUS =====
    Write-Log "Kontrollerar tjänststatus..." "Info"
    $serviceStatus = Get-ADFSServiceStatus

    if ($serviceStatus.ServiceState -ne "Running") {
        $analysis.Issues += "🚨 ADFS-tjänsten körs inte! Status: $($serviceStatus.ServiceState)"
        $analysis.HealthScore -= 30
    }

    # ===== REPLICERINGSSTATUS =====
    Write-Log "Kontrollerar replikering..." "Info"
    if ($serviceStatus.DKMStatus -ne "OK") {
        $analysis.Warnings += "DKM (Distributed Key Manager) status är inte OK: $($serviceStatus.DKMStatus)"
        $analysis.HealthScore -= 10
    }

    # ===== FÖRLITANDEPARTER HÄLSA =====
    Write-Log "Analyserar förlitandeparter..." "Info"
    $rpCount = (Get-ADFSRelyingPartyTrust | Measure-Object).Count
    $rpDisabled = (Get-ADFSRelyingPartyTrust | Where-Object { -not $_.Enabled } | Measure-Object).Count

    if ($rpDisabled -gt 0) {
        $analysis.Warnings += "$rpDisabled av $rpCount förlitandeparter är inaktiverade"
    }

    $rpNoMonitoring = (Get-ADFSRelyingPartyTrust | Where-Object { -not $_.MonitoringEnabled } | Measure-Object).Count
    if ($rpNoMonitoring -gt 0) {
        $analysis.Recommendations += "Aktivera övervakning för $rpNoMonitoring förlitandeparter"
        $analysis.HealthScore -= 3
    }

    # ===== CLAIMS PROVIDER ANALYS =====
    Write-Log "Analyserar claims providers..." "Info"
    $cpDisabled = (Get-ADFSClaimsProviderTrust | Where-Object { -not $_.Enabled } | Measure-Object).Count

    if ($cpDisabled -gt 0) {
        $analysis.Warnings += "$cpDisabled claims provider-förtroenden är inaktiverade"
    }

    # ===== SIGNERINGSCERTIFIKAT KONTROLL =====
    Write-Log "Kontrollerar signeringscertifikat..." "Info"
    $rps = Get-ADFSRelyingPartyTrust
    foreach ($rp in $rps) {
        if (-not $rp.SigningCertificate) {
            $analysis.Warnings += "Förlitandeparten '$($rp.Name)' har inget signeringscertifikat konfigurerat"
            $analysis.HealthScore -= 5
        }
    }

    # ===== CLAIMS RULES VALIDERING =====
    Write-Log "Validerar claims-regler..." "Info"
    $emptyRules = $rps | Where-Object { [string]::IsNullOrWhiteSpace($_.IssuanceTransformRules) }
    if ($emptyRules) {
        $analysis.Recommendations += "$($emptyRules.Count) förlitandeparter saknar issuance transform-regler"
        $analysis.HealthScore -= 3
    }

    # ===== ENDPOINTS AKTIVERING =====
    Write-Log "Kontrollerar endpoints..." "Info"
    $disabledEndpoints = Get-ADFSEndpoint | Where-Object { -not $_.Enabled }
    if ($disabledEndpoints) {
        $analysis.Warnings += "$($disabledEndpoints.Count) endpoints är inaktiverade"
    }

    # ===== ATTRIBUTLAGER KONTROLL =====
    Write-Log "Validerar attributlager..." "Info"
    $attrStores = Get-ADFSAttributeStore
    if ($attrStores.Count -eq 0) {
        $analysis.Issues += "⚠️  Inga attributlager är konfigurerade!"
        $analysis.HealthScore -= 10
    }

    # ===== AUTO-CERTIFIKATÖVERROLLNING =====
    Write-Log "Kontrollerar auto-certifikatöverrollning..." "Info"
    $props = Get-ADFSProperties
    if (-not $props.AutoCertificateRollover) {
        $analysis.Recommendations += "Aktivera automatisk certifikatöverrollning"
        $analysis.HealthScore -= 5
    }

    # Säkerställ minimum score
    if ($analysis.HealthScore -lt 0) { $analysis.HealthScore = 0 }

    # ===== EXPORTERA ANALYSRESULTAT =====
    Write-Log "Exporterar analysresultat..." "Info"

    # JSON-export
    $analysisJsonPath = Join-Path $OutputPath "ADFS_Analysis_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $analysis | ConvertTo-Json -Depth 10 | Out-File -FilePath $analysisJsonPath -Encoding UTF8

    # CSV-export av problem
    if ($analysis.Issues.Count -gt 0) {
        $csvPath = Join-Path $OutputPath "ADFS_Issues_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        $analysis.Issues | ForEach-Object { [PSCustomObject]@{Issue=$_; Severity="Critical"; Date=(Get-Date)} } | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    }

    # ===== KONSOLRAPPORT =====
    Write-Host ""
    Write-Host "╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║           ADFS-HÄLSOKONTROLLRAPPORT                            ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "📊 HÄLSOSCORE: " -ForegroundColor Yellow -NoNewline
    if ($analysis.HealthScore -ge 80) {
        Write-Host "$($analysis.HealthScore)/100 ✓" -ForegroundColor Green
    } elseif ($analysis.HealthScore -ge 60) {
        Write-Host "$($analysis.HealthScore)/100 ⚠️" -ForegroundColor Yellow
    } else {
        Write-Host "$($analysis.HealthScore)/100 🚨" -ForegroundColor Red
    }
    Write-Host ""

    if ($analysis.Issues.Count -gt 0) {
        Write-Host "🚨 KRITISKA PROBLEM ($($analysis.Issues.Count)):" -ForegroundColor Red
        foreach ($issue in $analysis.Issues) {
            Write-Host "   $issue" -ForegroundColor Red
        }
        Write-Host ""
    }

    if ($analysis.Warnings.Count -gt 0) {
        Write-Host "⚠️  VARNINGAR ($($analysis.Warnings.Count)):" -ForegroundColor Yellow
        foreach ($warning in $analysis.Warnings) {
            Write-Host "   • $warning" -ForegroundColor Yellow
        }
        Write-Host ""
    }

    if ($analysis.Recommendations.Count -gt 0) {
        Write-Host "💡 REKOMMENDATIONER ($($analysis.Recommendations.Count)):" -ForegroundColor Cyan
        foreach ($rec in $analysis.Recommendations) {
            Write-Host "   • $rec" -ForegroundColor Cyan
        }
        Write-Host ""
    }

    Write-Host "✓ Analys sparad till: $OutputPath" -ForegroundColor Green

} catch {
    Write-Log "Fel vid analys: $_" "Error"
    exit 1
}
