#Requires -Version 5.0

<#
.SYNOPSIS
    Jämför två ADFS-konfigurationer och visar skillnader.
.DESCRIPTION
    Läser två JSON-konfigurationsfiler från Get-ADFSConfiguration.ps1 och rapporterar på skillnader.
.PARAMETER OldConfig
    Sökväg till tidigare konfiguration (JSON)
.PARAMETER NewConfig
    Sökväg till ny konfiguration (JSON)
.EXAMPLE
    .\Compare-ADFSConfiguration.ps1 -OldConfig "ADFS_Config_20250101.json" -NewConfig "ADFS_Config_20250201.json"
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$OldConfig,

    [Parameter(Mandatory=$true)]
    [string]$NewConfig,

    [string]$OutputPath = "."
)

function Write-Log {
    param($Message, [ValidateSet("Info", "Success", "Warning", "Change")]$Level = "Info")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = @{Info = "White"; Success = "Green"; Warning = "Yellow"; Change = "Cyan"}
    Write-Host "[$timestamp] $Message" -ForegroundColor $color[$Level]
}

$changes = @{
    Added = @()
    Removed = @()
    Modified = @()
    Unchanged = 0
}

try {
    Write-Log "Laddar konfigurationsfiler..." "Info"

    if (-not (Test-Path $OldConfig)) {
        Write-Log "Gammal konfiguration finns inte: $OldConfig" "Warning"
        exit 1
    }

    if (-not (Test-Path $NewConfig)) {
        Write-Log "Ny konfiguration finns inte: $NewConfig" "Warning"
        exit 1
    }

    $old = Get-Content $OldConfig -Raw | ConvertFrom-Json
    $new = Get-Content $NewConfig -Raw | ConvertFrom-Json

    Write-Log "Konfigurationer inladdade" "Success"

    # ===== JÄMFÖR FÖRLITANDEPARTER =====
    Write-Log "Jämför förlitandeparter..." "Info"

    $oldRPNames = @($old.RelyingParties.Name)
    $newRPNames = @($new.RelyingParties.Name)

    $addedRP = $newRPNames | Where-Object { $_ -notin $oldRPNames }
    $removedRP = $oldRPNames | Where-Object { $_ -notin $newRPNames }
    $commonRP = $oldRPNames | Where-Object { $_ -in $newRPNames }

    if ($addedRP) {
        foreach ($rp in $addedRP) {
            $changes.Added += "[RP] Förlitandeparten lagts till: $rp"
        }
    }

    if ($removedRP) {
        foreach ($rp in $removedRP) {
            $changes.Removed += "[RP] Förlitandeparten borttagen: $rp"
        }
    }

    # Jämför ändringar i gemensamma RP:er
    foreach ($rpName in $commonRP) {
        $oldRP = $old.RelyingParties | Where-Object { $_.Name -eq $rpName }
        $newRP = $new.RelyingParties | Where-Object { $_.Name -eq $rpName }

        if ($oldRP.Enabled -ne $newRP.Enabled) {
            $status = if ($newRP.Enabled) { "aktiverad" } else { "inaktiverad" }
            $changes.Modified += "[RP] '$rpName' är nu $status"
        }

        if ($oldRP.MetadataUrl -ne $newRP.MetadataUrl) {
            $changes.Modified += "[RP] '$rpName' metadataURL ändrad"
        }

        if ((Compare-Object $oldRP.SigningCertificates.Thumbprint $newRP.SigningCertificates.Thumbprint)) {
            $changes.Modified += "[RP] '$rpName' signeringscertifikat ändrat"
        }
    }

    # ===== JÄMFÖR CLAIMS PROVIDERS =====
    Write-Log "Jämför claims providers..." "Info"

    $oldCPNames = @($old.ClaimsProviders.Name)
    $newCPNames = @($new.ClaimsProviders.Name)

    $addedCP = $newCPNames | Where-Object { $_ -notin $oldCPNames }
    $removedCP = $oldCPNames | Where-Object { $_ -notin $newCPNames }
    $commonCP = $oldCPNames | Where-Object { $_ -in $newCPNames }

    if ($addedCP) {
        foreach ($cp in $addedCP) {
            $changes.Added += "[CP] Claims provider lagts till: $cp"
        }
    }

    if ($removedCP) {
        foreach ($cp in $removedCP) {
            $changes.Removed += "[CP] Claims provider borttagen: $cp"
        }
    }

    foreach ($cpName in $commonCP) {
        $oldCP = $old.ClaimsProviders | Where-Object { $_.Name -eq $cpName }
        $newCP = $new.ClaimsProviders | Where-Object { $_.Name -eq $cpName }

        if ($oldCP.Enabled -ne $newCP.Enabled) {
            $status = if ($newCP.Enabled) { "aktiverad" } else { "inaktiverad" }
            $changes.Modified += "[CP] '$cpName' är nu $status"
        }
    }

    # ===== JÄMFÖR CERTIFIKAT =====
    Write-Log "Jämför certifikat..." "Info"

    $oldCerts = $old.Certificates.TokenSigningCertificate
    $newCerts = $new.Certificates.TokenSigningCertificate

    if ((Compare-Object $oldCerts.Thumbprint $newCerts.Thumbprint)) {
        $changes.Modified += "[CERT] Token-signeringscertifikat har ändrats"

        $addedCerts = $newCerts.Thumbprint | Where-Object { $_ -notin $oldCerts.Thumbprint }
        $removedCerts = $oldCerts.Thumbprint | Where-Object { $_ -notin $newCerts.Thumbprint }

        if ($addedCerts) {
            $changes.Added += "[CERT] Nya signeringscertifikat lagts till: $($addedCerts.Count) st"
        }

        if ($removedCerts) {
            $changes.Removed += "[CERT] Signeringscertifikat borttagna: $($removedCerts.Count) st"
        }
    }

    # ===== JÄMFÖR ATTRIBUTLAGER =====
    Write-Log "Jämför attributlager..." "Info"

    $oldAS = @($old.AttributeStores.Name)
    $newAS = @($new.AttributeStores.Name)

    $addedAS = $newAS | Where-Object { $_ -notin $oldAS }
    $removedAS = $oldAS | Where-Object { $_ -notin $newAS }

    if ($addedAS) {
        foreach ($as in $addedAS) {
            $changes.Added += "[AS] Attributlager lagts till: $as"
        }
    }

    if ($removedAS) {
        foreach ($as in $removedAS) {
            $changes.Removed += "[AS] Attributlager borttaget: $as"
        }
    }

    # ===== JÄMFÖR GLOBALA INSTÄLLNINGAR =====
    Write-Log "Jämför globala inställningar..." "Info"

    $oldProps = $old.GlobalSettings
    $newProps = $new.GlobalSettings

    if ($oldProps.AutoCertificateRollover -ne $newProps.AutoCertificateRollover) {
        $status = if ($newProps.AutoCertificateRollover) { "aktiverad" } else { "inaktiverad" }
        $changes.Modified += "[GLOBAL] Auto-certifikatöverrollning är nu $status"
    }

    if ($oldProps.HttpsPort -ne $newProps.HttpsPort) {
        $changes.Modified += "[GLOBAL] HTTPS-port ändrad från $($oldProps.HttpsPort) till $($newProps.HttpsPort)"
    }

    if ($oldProps.HttpPort -ne $newProps.HttpPort) {
        $changes.Modified += "[GLOBAL] HTTP-port ändrad från $($oldProps.HttpPort) till $($newProps.HttpPort)"
    }

    # ===== SKAPA RAPPORT =====
    Write-Log "Skapar rapport..." "Info"

    $reportPath = Join-Path $OutputPath "ADFS_Config_Comparison_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"

    $html = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ADFS Konfigurationsjämförelse</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        h1 { color: #0078d4; border-bottom: 3px solid #0078d4; padding-bottom: 10px; }
        h2 { color: #106ebe; margin-top: 25px; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .summary-box { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; }
        .summary-box.added { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .summary-box.removed { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        .summary-box.modified { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
        .summary-box h3 { margin: 0; font-size: 28px; }
        .summary-box p { margin: 5px 0 0 0; font-size: 12px; opacity: 0.9; }
        .change-list { margin: 20px 0; }
        .change-item { padding: 10px 15px; margin: 8px 0; border-radius: 4px; border-left: 4px solid; }
        .added-item { background-color: #e8f5e9; border-left-color: #4caf50; }
        .removed-item { background-color: #ffebee; border-left-color: #f44336; }
        .modified-item { background-color: #e3f2fd; border-left-color: #2196f3; }
        .timestamp { color: #666; font-size: 12px; margin-top: 20px; }
        .metadata { background-color: #f9f9f9; padding: 15px; border-radius: 4px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>ADFS Konfigurationsjämförelse</h1>

        <div class="metadata">
            <p><strong>Jämförelsedatum:</strong> $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
            <p><strong>Gammal konfiguration:</strong> $OldConfig</p>
            <p><strong>Ny konfiguration:</strong> $NewConfig</p>
        </div>

        <div class="summary">
            <div class="summary-box added">
                <h3>$($changes.Added.Count)</h3>
                <p>Tillagda objekt</p>
            </div>
            <div class="summary-box removed">
                <h3>$($changes.Removed.Count)</h3>
                <p>Borttagna objekt</p>
            </div>
            <div class="summary-box modified">
                <h3>$($changes.Modified.Count)</h3>
                <p>Modifierade objekt</p>
            </div>
        </div>

        <h2>📋 Sammanfattning</h2>
        <p>Denna rapport visar skillnaderna mellan två ADFS-konfigurationer.</p>
"@

    if ($changes.Added.Count -gt 0) {
        $html += @"
        <h2>✅ Tillagda objekt ($($changes.Added.Count))</h2>
        <div class="change-list">
"@
        foreach ($item in $changes.Added) {
            $html += "<div class='change-item added-item'>✓ $([System.Web.HttpUtility]::HtmlEncode($item))</div>"
        }
        $html += "</div>"
    }

    if ($changes.Removed.Count -gt 0) {
        $html += @"
        <h2>❌ Borttagna objekt ($($changes.Removed.Count))</h2>
        <div class="change-list">
"@
        foreach ($item in $changes.Removed) {
            $html += "<div class='change-item removed-item'>✗ $([System.Web.HttpUtility]::HtmlEncode($item))</div>"
        }
        $html += "</div>"
    }

    if ($changes.Modified.Count -gt 0) {
        $html += @"
        <h2>🔄 Modifierade objekt ($($changes.Modified.Count))</h2>
        <div class="change-list">
"@
        foreach ($item in $changes.Modified) {
            $html += "<div class='change-item modified-item'>⚡ $([System.Web.HttpUtility]::HtmlEncode($item))</div>"
        }
        $html += "</div>"
    }

    $html += @"
        <div class="timestamp">
            <p>Rapport genererad: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
        </div>
    </div>
</body>
</html>
"@

    $html | Out-File -FilePath $reportPath -Encoding UTF8

    # Konsolrapport
    Write-Host ""
    Write-Host "╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║         ADFS KONFIGURATIONSJÄMFÖRELSE - SAMMANFATTNING         ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "📊 RESULTAT:" -ForegroundColor Yellow
    Write-Host "  ✅ Tillagda objekt:     $($changes.Added.Count)"
    Write-Host "  ❌ Borttagna objekt:    $($changes.Removed.Count)"
    Write-Host "  🔄 Modifierade objekt:  $($changes.Modified.Count)"
    Write-Host ""

    if ($changes.Added.Count -gt 0) {
        Write-Host "✅ TILLAGDA OBJEKT:" -ForegroundColor Green
        foreach ($item in $changes.Added) {
            Write-Host "   • $item" -ForegroundColor Green
        }
        Write-Host ""
    }

    if ($changes.Removed.Count -gt 0) {
        Write-Host "❌ BORTTAGNA OBJEKT:" -ForegroundColor Red
        foreach ($item in $changes.Removed) {
            Write-Host "   • $item" -ForegroundColor Red
        }
        Write-Host ""
    }

    if ($changes.Modified.Count -gt 0) {
        Write-Host "🔄 MODIFIERADE OBJEKT:" -ForegroundColor Cyan
        foreach ($item in $changes.Modified) {
            Write-Host "   • $item" -ForegroundColor Cyan
        }
        Write-Host ""
    }

    Write-Log "Rapport sparad: $reportPath" "Success"

} catch {
    Write-Log "Fel vid jämförelse: $_" "Warning"
    exit 1
}
