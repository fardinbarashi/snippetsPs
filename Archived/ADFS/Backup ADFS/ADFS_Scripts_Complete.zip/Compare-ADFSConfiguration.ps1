#Requires -Version 5.0

<#
.SYNOPSIS
    Compares two ADFS configurations and displays differences.
.DESCRIPTION
    Reads two JSON configuration files from Get-ADFSConfiguration.ps1 and reports on differences.
    Uses ADFS-ReportTemplate.ps1 for HTML generation.
.PARAMETER OldConfig
    Path to previous configuration (JSON)
.PARAMETER NewConfig
    Path to new configuration (JSON)
.PARAMETER OutputPath
    Path where comparison report will be saved
.EXAMPLE
    .\Compare-ADFSConfiguration.ps1 -OldConfig "ADFS_Config_20250101.json" -NewConfig "ADFS_Config_20250201.json"
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$OldConfig,

    [Parameter(Mandatory=$true)]
    [string]$NewConfig,

    [string]$OutputPath = "."
)

# Get script directory
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Import report template module
$TemplateFile = Join-Path $ScriptDir "ADFS-ReportTemplate.ps1"
if (-not (Test-Path $TemplateFile)) {
    Write-Error "Report template file not found: $TemplateFile"
    exit 1
}
. $TemplateFile

function Write-Log {
    param(
        $Message,
        [ValidateSet("Info", "Success", "Warning", "Change")]$Level = "Info"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = @{
        Info = "White"
        Success = "Green"
        Warning = "Yellow"
        Change = "Cyan"
    }
    Write-Host "[$timestamp] $Message" -ForegroundColor $color[$Level]
}

$changes = @{
    Added = @()
    Removed = @()
    Modified = @()
    Unchanged = 0
}

try {
    Write-Log "Loading configuration files..." "Info"

    if (-not (Test-Path $OldConfig)) {
        Write-Log "Old configuration not found: $OldConfig" "Warning"
        exit 1
    }

    if (-not (Test-Path $NewConfig)) {
        Write-Log "New configuration not found: $NewConfig" "Warning"
        exit 1
    }

    $old = Get-Content $OldConfig -Raw | ConvertFrom-Json
    $new = Get-Content $NewConfig -Raw | ConvertFrom-Json

    Write-Log "Configurations loaded successfully" "Success"

    # ===== COMPARE RELYING PARTIES =====
    Write-Log "Comparing relying parties..." "Info"

    $oldRPNames = @($old.RelyingParties.Name)
    $newRPNames = @($new.RelyingParties.Name)

    $addedRP = $newRPNames | Where-Object { $_ -notin $oldRPNames }
    $removedRP = $oldRPNames | Where-Object { $_ -notin $newRPNames }
    $commonRP = $oldRPNames | Where-Object { $_ -in $newRPNames }

    if ($addedRP) {
        foreach ($rp in $addedRP) {
            $changes.Added += "[RP] Relying party added: $rp"
        }
    }

    if ($removedRP) {
        foreach ($rp in $removedRP) {
            $changes.Removed += "[RP] Relying party removed: $rp"
        }
    }

    # Compare changes in common RPs
    foreach ($rpName in $commonRP) {
        $oldRP = $old.RelyingParties | Where-Object { $_.Name -eq $rpName }
        $newRP = $new.RelyingParties | Where-Object { $_.Name -eq $rpName }

        if ($oldRP.Enabled -ne $newRP.Enabled) {
            $status = if ($newRP.Enabled) { "enabled" } else { "disabled" }
            $changes.Modified += "[RP] '$rpName' is now $status"
        }

        if ($oldRP.MetadataUrl -ne $newRP.MetadataUrl) {
            $changes.Modified += "[RP] '$rpName' metadata URL changed"
        }

        if ((Compare-Object $oldRP.SigningCertificates.Thumbprint $newRP.SigningCertificates.Thumbprint)) {
            $changes.Modified += "[RP] '$rpName' signing certificate changed"
        }
    }

    # ===== COMPARE CLAIMS PROVIDERS =====
    Write-Log "Comparing claims providers..." "Info"

    $oldCPNames = @($old.ClaimsProviders.Name)
    $newCPNames = @($new.ClaimsProviders.Name)

    $addedCP = $newCPNames | Where-Object { $_ -notin $oldCPNames }
    $removedCP = $oldCPNames | Where-Object { $_ -notin $newCPNames }
    $commonCP = $oldCPNames | Where-Object { $_ -in $newCPNames }

    if ($addedCP) {
        foreach ($cp in $addedCP) {
            $changes.Added += "[CP] Claims provider added: $cp"
        }
    }

    if ($removedCP) {
        foreach ($cp in $removedCP) {
            $changes.Removed += "[CP] Claims provider removed: $cp"
        }
    }

    foreach ($cpName in $commonCP) {
        $oldCP = $old.ClaimsProviders | Where-Object { $_.Name -eq $cpName }
        $newCP = $new.ClaimsProviders | Where-Object { $_.Name -eq $cpName }

        if ($oldCP.Enabled -ne $newCP.Enabled) {
            $status = if ($newCP.Enabled) { "enabled" } else { "disabled" }
            $changes.Modified += "[CP] '$cpName' is now $status"
        }
    }

    # ===== COMPARE CERTIFICATES =====
    Write-Log "Comparing certificates..." "Info"

    $oldCerts = $old.Certificates.TokenSigningCertificate
    $newCerts = $new.Certificates.TokenSigningCertificate

    if ((Compare-Object $oldCerts.Thumbprint $newCerts.Thumbprint)) {
        $changes.Modified += "[CERT] Token signing certificates have changed"

        $addedCerts = $newCerts.Thumbprint | Where-Object { $_ -notin $oldCerts.Thumbprint }
        $removedCerts = $oldCerts.Thumbprint | Where-Object { $_ -notin $newCerts.Thumbprint }

        if ($addedCerts) {
            $changes.Added += "[CERT] New signing certificates added: $($addedCerts.Count)"
        }

        if ($removedCerts) {
            $changes.Removed += "[CERT] Signing certificates removed: $($removedCerts.Count)"
        }
    }

    # ===== COMPARE ATTRIBUTE STORES =====
    Write-Log "Comparing attribute stores..." "Info"

    $oldAS = @($old.AttributeStores.Name)
    $newAS = @($new.AttributeStores.Name)

    $addedAS = $newAS | Where-Object { $_ -notin $oldAS }
    $removedAS = $oldAS | Where-Object { $_ -notin $newAS }

    if ($addedAS) {
        foreach ($as in $addedAS) {
            $changes.Added += "[AS] Attribute store added: $as"
        }
    }

    if ($removedAS) {
        foreach ($as in $removedAS) {
            $changes.Removed += "[AS] Attribute store removed: $as"
        }
    }

    # ===== COMPARE GLOBAL SETTINGS =====
    Write-Log "Comparing global settings..." "Info"

    $oldProps = $old.GlobalSettings
    $newProps = $new.GlobalSettings

    if ($oldProps.AutoCertificateRollover -ne $newProps.AutoCertificateRollover) {
        $status = if ($newProps.AutoCertificateRollover) { "enabled" } else { "disabled" }
        $changes.Modified += "[GLOBAL] Auto certificate rollover is now $status"
    }

    if ($oldProps.HttpsPort -ne $newProps.HttpsPort) {
        $changes.Modified += "[GLOBAL] HTTPS port changed from $($oldProps.HttpsPort) to $($newProps.HttpsPort)"
    }

    if ($oldProps.HttpPort -ne $newProps.HttpPort) {
        $changes.Modified += "[GLOBAL] HTTP port changed from $($oldProps.HttpPort) to $($newProps.HttpPort)"
    }

    # ===== CREATE REPORT =====
    Write-Log "Creating report..." "Info"

    $reportPath = Join-Path $OutputPath "ADFS_Config_Comparison_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

    # Call template function
    $htmlContent = Get-ComparisonReport -Changes $changes -OldConfig $OldConfig -NewConfig $NewConfig -Timestamp $timestamp
    $htmlContent | Out-File -FilePath $reportPath -Encoding UTF8

    # Console report
    Write-Host ""
    Write-Host "╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║    ADFS CONFIGURATION COMPARISON - SUMMARY                    ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "RESULTS:" -ForegroundColor Yellow
    Write-Host "  Items Added:     $($changes.Added.Count)"
    Write-Host "  Items Removed:   $($changes.Removed.Count)"
    Write-Host "  Items Modified:  $($changes.Modified.Count)"
    Write-Host ""

    if ($changes.Added.Count -gt 0) {
        Write-Host "ADDED ITEMS:" -ForegroundColor Green
        foreach ($item in $changes.Added) {
            Write-Host "   + $item" -ForegroundColor Green
        }
        Write-Host ""
    }

    if ($changes.Removed.Count -gt 0) {
        Write-Host "REMOVED ITEMS:" -ForegroundColor Red
        foreach ($item in $changes.Removed) {
            Write-Host "   - $item" -ForegroundColor Red
        }
        Write-Host ""
    }

    if ($changes.Modified.Count -gt 0) {
        Write-Host "MODIFIED ITEMS:" -ForegroundColor Cyan
        foreach ($item in $changes.Modified) {
            Write-Host "   ~ $item" -ForegroundColor Cyan
        }
        Write-Host ""
    }

    Write-Log "Report saved: $reportPath" "Success"

}
catch {
    Write-Log "Error during comparison: $_" "Warning"
    Write-Log $_.ScriptStackTrace "Warning"
    exit 1
}
