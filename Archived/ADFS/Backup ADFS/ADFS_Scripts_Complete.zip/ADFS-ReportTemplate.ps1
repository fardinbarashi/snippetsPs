#Requires -Version 5.0

<#
.SYNOPSIS
    HTML Report Templates for ADFS Configuration
.DESCRIPTION
    Contains functions to generate HTML reports for ADFS configuration
.NOTES
    This module is called by Get-ADFSConfiguration.ps1
#>

<#
.FUNCTION
    Get-ConfigurationReport
    Generates main ADFS configuration HTML report
#>
function Get-ConfigurationReport {
    param(
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$Config,

        [Parameter(Mandatory=$true)]
        [string]$Timestamp
    )

    $rpCount = ($config.RelyingParties | Measure-Object).Count
    $cpCount = ($config.ClaimsProviders | Measure-Object).Count
    $certCount = ($config.Certificates.TokenSigningCertificate | Measure-Object).Count

    # Build certificate rows
    $certRows = ""
    foreach ($cert in $config.Certificates.TokenSigningCertificate) {
        $daysLeft = $cert.DaysToExpiry
        $statusClass = if ($daysLeft -lt 30) { "expiry-critical" } elseif ($daysLeft -lt 90) { "expiry-warning" } else { "" }
        $statusText = if ($daysLeft -lt 0) { "<span class='warning'>EXPIRED</span>" } else { "$daysLeft days" }
        $typeText = if($cert.IsPrimary) { "Primary" } else { "Backup" }
        $subject = [System.Web.HttpUtility]::HtmlEncode($cert.SubjectName)
        $thumb = [System.Web.HttpUtility]::HtmlEncode($cert.Thumbprint)
        $valid = [System.Web.HttpUtility]::HtmlEncode($cert.ValidTo)

        $certRows += @"
            <tr class="$statusClass">
                <td>$subject</td>
                <td>$thumb</td>
                <td>$valid</td>
                <td>$statusText</td>
                <td>$typeText</td>
            </tr>
"@
    }

    # Build relying parties rows
    $rpRows = ""
    foreach ($rp in $config.RelyingParties) {
        $enabled = if ($rp.Enabled) { "Yes" } else { "No" }
        $monitoring = if ($rp.MonitoringEnabled) { "Yes" } else { "No" }
        $name = [System.Web.HttpUtility]::HtmlEncode($rp.Name)
        $identifier = [System.Web.HttpUtility]::HtmlEncode($rp.Identifier[0])
        $protocol = [System.Web.HttpUtility]::HtmlEncode($rp.ProtocolProfile)

        $rpRows += @"
            <tr>
                <td>$name</td>
                <td>$identifier</td>
                <td>$enabled</td>
                <td>$protocol</td>
                <td>$monitoring</td>
            </tr>
"@
    }

    # Build claims providers rows
    $cpRows = ""
    foreach ($cp in $config.ClaimsProviders) {
        $enabled = if ($cp.Enabled) { "Yes" } else { "No" }
        $name = [System.Web.HttpUtility]::HtmlEncode($cp.Name)
        $identifier = [System.Web.HttpUtility]::HtmlEncode($cp.Identifier)
        $protocols = [System.Web.HttpUtility]::HtmlEncode(($cp.ProtocolSupportEnumeration -join ', '))

        $cpRows += @"
            <tr>
                <td>$name</td>
                <td>$identifier</td>
                <td>$enabled</td>
                <td>$protocols</td>
            </tr>
"@
    }

    # Service info
    $serviceName = [System.Web.HttpUtility]::HtmlEncode($config.ServiceInfo.ServiceName)
    $serviceRole = [System.Web.HttpUtility]::HtmlEncode($config.ServiceInfo.ServiceRole)
    $hostname = [System.Web.HttpUtility]::HtmlEncode($config.ServiceInfo.FullyQualifiedDomainName)
    $status = [System.Web.HttpUtility]::HtmlEncode($config.ServiceInfo.Status)
    $version = [System.Web.HttpUtility]::HtmlEncode($config.ServiceInfo.Version)

    # Global settings
    $orgName = [System.Web.HttpUtility]::HtmlEncode($config.GlobalSettings.OrganizationName)
    $autoCert = [System.Web.HttpUtility]::HtmlEncode($config.GlobalSettings.AutoCertificateRollover)
    $certThreshold = [System.Web.HttpUtility]::HtmlEncode($config.GlobalSettings.CertificateThresholdDays)
    $httpPort = [System.Web.HttpUtility]::HtmlEncode($config.GlobalSettings.HttpPort)
    $httpsPort = [System.Web.HttpUtility]::HtmlEncode($config.GlobalSettings.HttpsPort)

    # Build complete HTML
    $html = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ADFS Configuration Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        h1 {
            color: #0078d4;
            border-bottom: 2px solid #0078d4;
            padding-bottom: 10px;
        }
        h2 {
            color: #106ebe;
            margin-top: 30px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 15px 0;
            background-color: white;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #0078d4;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .info-box {
            background-color: #e3f2fd;
            border-left: 4px solid #0078d4;
            padding: 15px;
            margin: 10px 0;
        }
        .warning {
            color: #d32f2f;
            font-weight: bold;
        }
        .success {
            color: #388e3c;
            font-weight: bold;
        }
        .expiry-critical {
            background-color: #ffebee;
        }
        .expiry-warning {
            background-color: #fff3e0;
        }
        .footer {
            margin-top: 40px;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ADFS Configuration Report</h1>
        <div class="info-box">
            <p><strong>Generated:</strong> $Timestamp</p>
        </div>

        <h2>1. ADFS Service Information</h2>
        <table>
            <tr>
                <th>Property</th>
                <th>Value</th>
            </tr>
            <tr>
                <td>Service Name</td>
                <td>$serviceName</td>
            </tr>
            <tr>
                <td>Role</td>
                <td>$serviceRole</td>
            </tr>
            <tr>
                <td>Host Name</td>
                <td>$hostname</td>
            </tr>
            <tr>
                <td>Status</td>
                <td class="success">$status</td>
            </tr>
            <tr>
                <td>Version</td>
                <td>$version</td>
            </tr>
        </table>

        <h2>2. Token Signing Certificates ($certCount)</h2>
        <table>
            <tr>
                <th>Subject</th>
                <th>Thumbprint</th>
                <th>Valid Until</th>
                <th>Days Remaining</th>
                <th>Type</th>
            </tr>
$certRows
        </table>

        <h2>3. Relying Parties ($rpCount)</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Identifier</th>
                <th>Enabled</th>
                <th>Protocol</th>
                <th>Monitoring</th>
            </tr>
$rpRows
        </table>

        <h2>4. Claims Provider Trusts ($cpCount)</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Identifier</th>
                <th>Enabled</th>
                <th>Protocols</th>
            </tr>
$cpRows
        </table>

        <h2>5. Global Settings</h2>
        <table>
            <tr>
                <th>Setting</th>
                <th>Value</th>
            </tr>
            <tr>
                <td>Organization Name</td>
                <td>$orgName</td>
            </tr>
            <tr>
                <td>Auto Certificate Rollover</td>
                <td>$autoCert</td>
            </tr>
            <tr>
                <td>Certificate Threshold Days</td>
                <td>$certThreshold</td>
            </tr>
            <tr>
                <td>HTTP Port</td>
                <td>$httpPort</td>
            </tr>
            <tr>
                <td>HTTPS Port</td>
                <td>$httpsPort</td>
            </tr>
        </table>

        <div class="footer">
            <p><strong>Data Files:</strong></p>
            <p>JSON Export: ADFS_Config_*.json</p>
            <p>Report generated by Get-ADFSConfiguration.ps1</p>
        </div>
    </div>
</body>
</html>
"@

    return $html
}

<#
.FUNCTION
    Get-ComparisonReport
    Generates configuration comparison HTML report
#>
function Get-ComparisonReport {
    param(
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$Changes,

        [Parameter(Mandatory=$true)]
        [string]$OldConfig,

        [Parameter(Mandatory=$true)]
        [string]$NewConfig,

        [Parameter(Mandatory=$true)]
        [string]$Timestamp
    )

    # Build added items
    $addedRows = ""
    foreach ($item in $Changes.Added) {
        $encoded = [System.Web.HttpUtility]::HtmlEncode($item)
        $addedRows += "        <div class='change-item added-item'>$encoded</div>`n"
    }

    # Build removed items
    $removedRows = ""
    foreach ($item in $Changes.Removed) {
        $encoded = [System.Web.HttpUtility]::HtmlEncode($item)
        $removedRows += "        <div class='change-item removed-item'>$encoded</div>`n"
    }

    # Build modified items
    $modifiedRows = ""
    foreach ($item in $Changes.Modified) {
        $encoded = [System.Web.HttpUtility]::HtmlEncode($item)
        $modifiedRows += "        <div class='change-item modified-item'>$encoded</div>`n"
    }

    $oldPath = [System.Web.HttpUtility]::HtmlEncode($OldConfig)
    $newPath = [System.Web.HttpUtility]::HtmlEncode($NewConfig)

    $html = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>ADFS Configuration Comparison</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #0078d4;
            border-bottom: 3px solid #0078d4;
            padding-bottom: 10px;
        }
        h2 {
            color: #106ebe;
            margin-top: 25px;
        }
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .summary-box {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .summary-box.added {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        .summary-box.removed {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        .summary-box.modified {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }
        .summary-box h3 {
            margin: 0;
            font-size: 28px;
        }
        .summary-box p {
            margin: 5px 0 0 0;
            font-size: 12px;
            opacity: 0.9;
        }
        .change-list {
            margin: 20px 0;
        }
        .change-item {
            padding: 10px 15px;
            margin: 8px 0;
            border-radius: 4px;
            border-left: 4px solid;
        }
        .added-item {
            background-color: #e8f5e9;
            border-left-color: #4caf50;
        }
        .removed-item {
            background-color: #ffebee;
            border-left-color: #f44336;
        }
        .modified-item {
            background-color: #e3f2fd;
            border-left-color: #2196f3;
        }
        .metadata {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .footer {
            margin-top: 20px;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ADFS Configuration Comparison</h1>

        <div class="metadata">
            <p><strong>Comparison Date:</strong> $Timestamp</p>
            <p><strong>Old Configuration:</strong> $oldPath</p>
            <p><strong>New Configuration:</strong> $newPath</p>
        </div>

        <div class="summary">
            <div class="summary-box added">
                <h3>$($Changes.Added.Count)</h3>
                <p>Added Items</p>
            </div>
            <div class="summary-box removed">
                <h3>$($Changes.Removed.Count)</h3>
                <p>Removed Items</p>
            </div>
            <div class="summary-box modified">
                <h3>$($Changes.Modified.Count)</h3>
                <p>Modified Items</p>
            </div>
        </div>

        <h2>Summary</h2>
        <p>This report shows the differences between two ADFS configurations.</p>
"@

    if ($Changes.Added.Count -gt 0) {
        $html += @"

        <h2>Added Items ($($Changes.Added.Count))</h2>
        <div class="change-list">
$addedRows
        </div>
"@
    }

    if ($Changes.Removed.Count -gt 0) {
        $html += @"

        <h2>Removed Items ($($Changes.Removed.Count))</h2>
        <div class="change-list">
$removedRows
        </div>
"@
    }

    if ($Changes.Modified.Count -gt 0) {
        $html += @"

        <h2>Modified Items ($($Changes.Modified.Count))</h2>
        <div class="change-list">
$modifiedRows
        </div>
"@
    }

    $html += @"

        <div class="footer">
            <p>Report generated: $Timestamp</p>
        </div>
    </div>
</body>
</html>
"@

    return $html
}

Export-ModuleMember -Function Get-ConfigurationReport, Get-ComparisonReport
