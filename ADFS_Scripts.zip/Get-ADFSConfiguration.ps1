#Requires -RunAsAdministrator
#Requires -Modules ADFS

<#
.SYNOPSIS
    Retrieves complete ADFS configuration including claims, certificates, relying parties, etc.
.DESCRIPTION
    Exports all ADFS configuration to JSON and HTML files for analysis and documentation.
    Uses ADFS-ReportTemplate.ps1 for HTML generation.
.PARAMETER OutputPath
    Path where configuration will be saved (default: C:\ADFS_Config)
.PARAMETER OpenReport
    Automatically open the HTML report after export
.EXAMPLE
    .\Get-ADFSConfiguration.ps1 -OutputPath "C:\ADFS_Config" -OpenReport
#>

param(
    [string]$OutputPath = "C:\ADFS_Config",
    [switch]$OpenReport
)

# Get script directory
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Import report template module
$TemplateFile = Join-Path $ScriptDir "ADFS-ReportTemplate.ps1"
if (-not (Test-Path $TemplateFile)) {
    Write-Error "Report template file not found: $TemplateFile"
    exit 1
}
. $TemplateFile

# Function to write log messages
function Write-Log {
    param(
        $Message,
        [ValidateSet("Info", "Success", "Warning", "Error")]$Level = "Info"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = @{
        Info = "White"
        Success = "Green"
        Warning = "Yellow"
        Error = "Red"
    }
    Write-Host "[$timestamp] $Message" -ForegroundColor $color[$Level]
}

# Create output directory
if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null
    Write-Log "Created directory: $OutputPath" "Success"
}

$config = @{}

try {
    Write-Log "Retrieving ADFS service information..." "Info"

    # ===== ADFS SERVICE CONFIGURATION =====
    $adfsProps = Get-ADFSProperties

    # Get service status (may not be available in older ADFS versions)
    $serviceStatus = "Unknown"
    try {
        if (Get-Command Get-ADFSServiceStatus -ErrorAction SilentlyContinue) {
            $serviceStatus = (Get-ADFSServiceStatus).ServiceState
        }
    }
    catch {
        Write-Log "Service status unavailable (ADFS 2012 R2 or older)" "Warning"
    }

    $config.ServiceInfo = @{
        ServiceName = $adfsProps.DisplayName
        ServiceRole = $adfsProps.Role
        FullyQualifiedDomainName = $adfsProps.HostName
        Status = $serviceStatus
        Version = $adfsProps.ProductVersion
        Timestamp = Get-Date -Format "o"
    }

    # ===== CERTIFICATES =====
    Write-Log "Retrieving certificates..." "Info"
    $config.Certificates = @{
        ServiceCommunicationCertificate = @(
            Get-ADFSCertificate | Where-Object { $_.CertificateType -eq "Service-Communication" } | ForEach-Object {
                @{
                    Thumbprint = $_.Thumbprint
                    SubjectName = $_.Certificate.Subject
                    IssuerName = $_.Certificate.Issuer
                    ValidFrom = $_.Certificate.NotBefore
                    ValidTo = $_.Certificate.NotAfter
                    DaysToExpiry = ($_.Certificate.NotAfter - (Get-Date)).Days
                    CertificateHash = $_.Thumbprint
                }
            }
        )
        TokenSigningCertificate = @(
            Get-ADFSCertificate | Where-Object { $_.CertificateType -eq "Token-Signing" } | ForEach-Object {
                @{
                    Thumbprint = $_.Thumbprint
                    SubjectName = $_.Certificate.Subject
                    IssuerName = $_.Certificate.Issuer
                    ValidFrom = $_.Certificate.NotBefore
                    ValidTo = $_.Certificate.NotAfter
                    DaysToExpiry = ($_.Certificate.NotAfter - (Get-Date)).Days
                    IsPrimary = $_.IsPrimary
                }
            }
        )
    }

    # ===== RELYING PARTIES =====
    Write-Log "Retrieving relying parties..." "Info"
    $relyingParties = Get-ADFSRelyingPartyTrust
    $config.RelyingParties = @()

    foreach ($rp in $relyingParties) {
        $rpConfig = @{
            Identifier = $rp.Identifier
            Name = $rp.Name
            Enabled = $rp.Enabled
            AccessControlPolicyName = $rp.AccessControlPolicyName
            ClaimsProviderName = $rp.ClaimsProviderName
            ProtocolProfile = $rp.ProtocolProfile
            RequestSigningCertificateRevocationCheck = $rp.RequestSigningCertificateRevocationCheck
            SigningCertificateRevocationCheck = $rp.SigningCertificateRevocationCheck
            SignedSamlRequestsRequired = $rp.SignedSamlRequestsRequired
            SamlResponseSignature = $rp.SamlResponseSignature
            WsFedEndpoint = $rp.WSFedEndpoint
            MetadataUrl = $rp.MetadataUrl
            MonitoringEnabled = $rp.MonitoringEnabled
            Notes = $rp.Notes
            IssuanceAuthorizationRules = $rp.IssuanceAuthorizationRules
            IssuanceTransformRules = $rp.IssuanceTransformRules

            # Signing certificates
            SigningCertificates = @($rp.SigningCertificate | ForEach-Object {
                @{
                    Thumbprint = $_
                    Certificate = (Get-ChildItem Cert:\LocalMachine\My\$_).Subject
                }
            })

            # WS-Fed and SAML endpoints
            WsFedEndpoints = @(
                $rp.WSFedEndpoint | ForEach-Object { @{ Endpoint = $_ } }
            )

            SamlEndpoints = @(
                $rp.SamlEndpoints | ForEach-Object {
                    @{
                        Binding = $_.Binding
                        Location = $_.Location
                        Index = $_.Index
                        IsDefault = $_.IsDefault
                    }
                }
            )
        }

        $config.RelyingParties += $rpConfig
    }

    # ===== CLAIMS PROVIDER TRUSTS =====
    Write-Log "Retrieving claims provider trusts..." "Info"
    $claimsProviders = Get-ADFSClaimsProviderTrust
    $config.ClaimsProviders = @()

    foreach ($cp in $claimsProviders) {
        $cpConfig = @{
            Identifier = $cp.Identifier
            Name = $cp.Name
            Enabled = $cp.Enabled
            ProtocolSupportEnumeration = $cp.ProtocolSupportEnumeration
            MonitoringEnabled = $cp.MonitoringEnabled
            Notes = $cp.Notes
            IssuanceAuthorizationRules = $cp.IssuanceAuthorizationRules
            IssuanceTransformRules = $cp.IssuanceTransformRules
            AcceptanceTransformRules = $cp.AcceptanceTransformRules

            # Endpoints
            Endpoints = @()
        }

        if ($cp.Endpoints) {
            $cpConfig.Endpoints = @(
                $cp.Endpoints | ForEach-Object {
                    @{
                        Protocol = $_.Protocol
                        Binding = $_.Binding
                        Location = $_.Location
                    }
                }
            )
        }

        $config.ClaimsProviders += $cpConfig
    }

    # ===== CLAIMS RULES =====
    Write-Log "Retrieving claims rules..." "Info"
    $config.ClaimsRules = @{
        RelyingPartyClaimsRules = @()
        ClaimsProviderClaimsRules = @()
    }

    # Relying party claims rules
    foreach ($rp in $relyingParties) {
        $config.ClaimsRules.RelyingPartyClaimsRules += @{
            RelyingPartyName = $rp.Name
            IssuanceAuthorizationRules = $rp.IssuanceAuthorizationRules
            IssuanceTransformRules = $rp.IssuanceTransformRules
            DelegationAuthorizationRules = $rp.DelegationAuthorizationRules
        }
    }

    # Claims provider rules
    foreach ($cp in $claimsProviders) {
        $config.ClaimsRules.ClaimsProviderClaimsRules += @{
            ClaimsProviderName = $cp.Name
            IssuanceAuthorizationRules = $cp.IssuanceAuthorizationRules
            IssuanceTransformRules = $cp.IssuanceTransformRules
            AcceptanceTransformRules = $cp.AcceptanceTransformRules
        }
    }

    # ===== ATTRIBUTE STORES =====
    Write-Log "Retrieving attribute stores..." "Info"
    $config.AttributeStores = @(
        Get-ADFSAttributeStore | ForEach-Object {
            @{
                Name = $_.Name
                Type = $_.Type
                Configuration = $_.Configuration
            }
        }
    )

    # ===== SCOPE DESCRIPTIONS =====
    Write-Log "Retrieving scope descriptions..." "Info"
    $config.ScopeDescriptions = @(
        Get-ADFSScopeDescription | ForEach-Object {
            @{
                Name = $_.Name
                Description = $_.Description
                Identifier = $_.Identifier
            }
        }
    )

    # ===== GLOBAL POLICY SETTINGS =====
    Write-Log "Retrieving global settings..." "Info"
    $config.GlobalSettings = @{
        DisplayName = $adfsProps.DisplayName
        OrganizationName = $adfsProps.OrganizationName
        OrganizationalUnitName = $adfsProps.OrganizationalUnitName
        WebApplicationProxyConfiguration = $adfsProps.WebApplicationProxyConfiguration
        ExtendedProperties = $adfsProps.ExtendedProperties
        AutoCertificateRollover = $adfsProps.AutoCertificateRollover
        CertificateCriticalThresholdDays = $adfsProps.CertificateCriticalThresholdDays
        CertificatePromotionThresholdDays = $adfsProps.CertificatePromotionThresholdDays
        CertificateRolloverInterval = $adfsProps.CertificateRolloverInterval
        CertificateSharingContainer = $adfsProps.CertificateSharingContainer
        CertificateThresholdDays = $adfsProps.CertificateThresholdDays
        HostName = $adfsProps.HostName
        HttpPort = $adfsProps.HttpPort
        HttpsPort = $adfsProps.HttpsPort
        IntranetUseMultiLanguage = $adfsProps.IntranetUseMultiLanguage
        Proxies = $adfsProps.Proxies
    }

    # ===== AUTHENTICATION POLICIES =====
    Write-Log "Retrieving authentication policies..." "Info"
    try {
        $config.AuthenticationPolicies = @(
            Get-AdfsAuthenticationPolicy | ForEach-Object {
                @{
                    Name = $_.Name
                    UserAuthenticationPolicy = $_.UserAuthenticationPolicy
                    ExtranetAuthenticationPolicy = $_.ExtranetAuthenticationPolicy
                    DeviceAuthenticationEnabled = $_.DeviceAuthenticationEnabled
                }
            }
        )
    }
    catch {
        Write-Log "Could not retrieve authentication policies (requires ADFS 2016 or later)" "Warning"
    }

    # ===== ADMIN ACCOUNTS =====
    Write-Log "Retrieving ADFS administrators..." "Info"
    try {
        $config.AdminAccounts = @(
            Get-ADFSAdministrationRole | ForEach-Object {
                @{
                    Identifier = $_.Identifier
                    Role = $_.Role
                }
            }
        )
    }
    catch {
        Write-Log "Could not retrieve administrator roles" "Warning"
    }

    # ===== ENDPOINT CONFIGURATION =====
    Write-Log "Retrieving endpoints..." "Info"
    $config.Endpoints = @(
        Get-ADFSEndpoint | ForEach-Object {
            @{
                FullUrl = $_.FullUrl
                Protocol = $_.Protocol
                AddressPath = $_.AddressPath
                Enabled = $_.Enabled
            }
        }
    )

    # ===== EXPORT TO JSON =====
    Write-Log "Exporting configuration to JSON..." "Info"
    $jsonPath = Join-Path $OutputPath "ADFS_Config_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $config | ConvertTo-Json -Depth 10 | Out-File -FilePath $jsonPath -Encoding UTF8
    Write-Log "Saved JSON: $jsonPath" "Success"

    # ===== EXPORT TO HTML REPORT =====
    Write-Log "Creating HTML report..." "Info"
    $htmlPath = Join-Path $OutputPath "ADFS_Config_$(Get-Date -Format 'yyyyMMdd_HHmmss').html"
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

    # Call template function
    $htmlContent = Get-ConfigurationReport -Config $config -Timestamp $timestamp
    $htmlContent | Out-File -FilePath $htmlPath -Encoding UTF8

    Write-Log "Saved HTML report: $htmlPath" "Success"

    # Open report if requested
    if ($OpenReport) {
        Invoke-Item $htmlPath
    }

    Write-Log "ADFS configuration exported successfully!" "Success"
    Write-Log "Files saved to: $OutputPath" "Info"

}
catch {
    Write-Log "Error retrieving configuration: $_" "Error"
    Write-Log $_.ScriptStackTrace "Error"
    exit 1
}
