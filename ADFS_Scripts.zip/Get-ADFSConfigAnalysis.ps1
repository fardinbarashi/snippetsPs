#Requires -RunAsAdministrator
#Requires -Modules ADFS

<#
.SYNOPSIS
    Analyzes ADFS configuration and reports on security and health.
.DESCRIPTION
    Performs security and health checks on the ADFS environment.
.PARAMETER OutputPath
    Path where analysis results will be saved (default: C:\ADFS_Config)
#>

param(
    [string]$OutputPath = "C:\ADFS_Config"
)

function Write-Log {
    param(
        $Message,
        [ValidateSet("Info", "Success", "Warning", "Error")]$Level = "Info"
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $color = @{
        Info = "White"
        Success = "Green"
        Warning = "Yellow"
        Error = "Red"
    }
    Write-Host "[$timestamp] $Message" -ForegroundColor $color[$Level]
}

$analysis = @{
    Issues = @()
    Warnings = @()
    Recommendations = @()
    HealthScore = 100
}

try {
    Write-Log "Starting ADFS health check..." "Info"

    # ===== CERTIFICATE ANALYSIS =====
    Write-Log "Analyzing certificates..." "Info"
    $certs = Get-ADFSCertificate

    foreach ($cert in $certs) {
        $daysToExpiry = ($cert.Certificate.NotAfter - (Get-Date)).Days

        if ($daysToExpiry -lt 0) {
            $analysis.Issues += "CRITICAL: Certificate $($cert.Certificate.Subject) has EXPIRED!"
            $analysis.HealthScore -= 25
        }
        elseif ($daysToExpiry -lt 30) {
            $analysis.Issues += "URGENT: Certificate $($cert.Certificate.Subject) expires in $daysToExpiry days!"
            $analysis.HealthScore -= 15
        }
        elseif ($daysToExpiry -lt 90) {
            $analysis.Warnings += "Certificate $($cert.Certificate.Subject) expires in $daysToExpiry days"
            $analysis.HealthScore -= 5
        }
    }

    # ===== SERVICE STATUS =====
    Write-Log "Checking service status..." "Info"
    try {
        if (Get-Command Get-ADFSServiceStatus -ErrorAction SilentlyContinue) {
            $serviceStatus = Get-ADFSServiceStatus

            if ($serviceStatus.ServiceState -ne "Running") {
                $analysis.Issues += "CRITICAL: ADFS service is not running! Status: $($serviceStatus.ServiceState)"
                $analysis.HealthScore -= 30
            }

            # ===== REPLICATION STATUS =====
            Write-Log "Checking replication..." "Info"
            if ($serviceStatus.DKMStatus -ne "OK") {
                $analysis.Warnings += "DKM (Distributed Key Manager) status is not OK: $($serviceStatus.DKMStatus)"
                $analysis.HealthScore -= 10
            }
        }
        else {
            Write-Log "Service status check unavailable (ADFS 2012 R2 or older)" "Warning"
        }
    }
    catch {
        Write-Log "Could not check service status: $_" "Warning"
    }

    # ===== RELYING PARTIES HEALTH =====
    Write-Log "Analyzing relying parties..." "Info"
    $rpCount = (Get-ADFSRelyingPartyTrust | Measure-Object).Count
    $rpDisabled = (Get-ADFSRelyingPartyTrust | Where-Object { -not $_.Enabled } | Measure-Object).Count

    if ($rpDisabled -gt 0) {
        $analysis.Warnings += "$rpDisabled of $rpCount relying parties are disabled"
    }

    $rpNoMonitoring = (Get-ADFSRelyingPartyTrust | Where-Object { -not $_.MonitoringEnabled } | Measure-Object).Count
    if ($rpNoMonitoring -gt 0) {
        $analysis.Recommendations += "Enable monitoring for $rpNoMonitoring relying parties"
        $analysis.HealthScore -= 3
    }

    # ===== CLAIMS PROVIDER ANALYSIS =====
    Write-Log "Analyzing claims providers..." "Info"
    $cpDisabled = (Get-ADFSClaimsProviderTrust | Where-Object { -not $_.Enabled } | Measure-Object).Count

    if ($cpDisabled -gt 0) {
        $analysis.Warnings += "$cpDisabled claims provider trusts are disabled"
    }

    # ===== SIGNING CERTIFICATE CHECK =====
    Write-Log "Checking signing certificates..." "Info"
    $rps = Get-ADFSRelyingPartyTrust
    foreach ($rp in $rps) {
        if (-not $rp.SigningCertificate) {
            $analysis.Warnings += "Relying party '$($rp.Name)' has no signing certificate configured"
            $analysis.HealthScore -= 5
        }
    }

    # ===== CLAIMS RULES VALIDATION =====
    Write-Log "Validating claims rules..." "Info"
    $emptyRules = $rps | Where-Object { [string]::IsNullOrWhiteSpace($_.IssuanceTransformRules) }
    if ($emptyRules) {
        $analysis.Recommendations += "$($emptyRules.Count) relying parties lack issuance transform rules"
        $analysis.HealthScore -= 3
    }

    # ===== ENDPOINTS ACTIVATION =====
    Write-Log "Checking endpoints..." "Info"
    $disabledEndpoints = Get-ADFSEndpoint | Where-Object { -not $_.Enabled }
    if ($disabledEndpoints) {
        $analysis.Warnings += "$($disabledEndpoints.Count) endpoints are disabled"
    }

    # ===== ATTRIBUTE STORE CHECK =====
    Write-Log "Validating attribute stores..." "Info"
    $attrStores = Get-ADFSAttributeStore
    if ($attrStores.Count -eq 0) {
        $analysis.Issues += "WARNING: No attribute stores are configured!"
        $analysis.HealthScore -= 10
    }

    # ===== AUTO CERTIFICATE ROLLOVER =====
    Write-Log "Checking auto certificate rollover..." "Info"
    $props = Get-ADFSProperties
    if (-not $props.AutoCertificateRollover) {
        $analysis.Recommendations += "Enable automatic certificate rollover"
        $analysis.HealthScore -= 5
    }

    # Ensure minimum score
    if ($analysis.HealthScore -lt 0) { $analysis.HealthScore = 0 }

    # ===== EXPORT ANALYSIS RESULTS =====
    Write-Log "Exporting analysis results..." "Info"

    # JSON export
    $analysisJsonPath = Join-Path $OutputPath "ADFS_Analysis_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $analysis | ConvertTo-Json -Depth 10 | Out-File -FilePath $analysisJsonPath -Encoding UTF8

    # CSV export of issues
    if ($analysis.Issues.Count -gt 0) {
        $csvPath = Join-Path $OutputPath "ADFS_Issues_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
        $analysis.Issues | ForEach-Object {
            [PSCustomObject]@{
                Issue = $_
                Severity = "Critical"
                Date = (Get-Date)
            }
        } | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
    }

    # ===== CONSOLE REPORT =====
    Write-Host ""
    Write-Host "╔════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║           ADFS HEALTH CHECK REPORT                             ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""

    Write-Host "HEALTH SCORE: " -ForegroundColor Yellow -NoNewline
    if ($analysis.HealthScore -ge 80) {
        Write-Host "$($analysis.HealthScore)/100 [OK]" -ForegroundColor Green
    }
    elseif ($analysis.HealthScore -ge 60) {
        Write-Host "$($analysis.HealthScore)/100 [WARNING]" -ForegroundColor Yellow
    }
    else {
        Write-Host "$($analysis.HealthScore)/100 [CRITICAL]" -ForegroundColor Red
    }
    Write-Host ""

    if ($analysis.Issues.Count -gt 0) {
        Write-Host "CRITICAL ISSUES ($($analysis.Issues.Count)):" -ForegroundColor Red
        foreach ($issue in $analysis.Issues) {
            Write-Host "   $issue" -ForegroundColor Red
        }
        Write-Host ""
    }

    if ($analysis.Warnings.Count -gt 0) {
        Write-Host "WARNINGS ($($analysis.Warnings.Count)):" -ForegroundColor Yellow
        foreach ($warning in $analysis.Warnings) {
            Write-Host "   - $warning" -ForegroundColor Yellow
        }
        Write-Host ""
    }

    if ($analysis.Recommendations.Count -gt 0) {
        Write-Host "RECOMMENDATIONS ($($analysis.Recommendations.Count)):" -ForegroundColor Cyan
        foreach ($rec in $analysis.Recommendations) {
            Write-Host "   - $rec" -ForegroundColor Cyan
        }
        Write-Host ""
    }

    Write-Host "Analysis saved to: $OutputPath" -ForegroundColor Green

}
catch {
    Write-Log "Error during analysis: $_" "Error"
    exit 1
}
